

import java.io.*;
import java.util.ArrayList;

// Custom exception for insufficient funds
class InsufficientFundsException extends Exception {
    public InsufficientFundsException(String message) {
        super(message);
    }
}

// Main BankAccount class
public class BankAccount {
    private String accountNumber;
    private String accountHolderName;
    protected double balance; // Changed to protected for subclass access
    private ArrayList<String> transactions;

    // Constructor
    public BankAccount(String accountNumber, String accountHolderName, double balance) {
        this.accountNumber = accountNumber;
        this.accountHolderName = accountHolderName;
        this.balance = balance;
        this.transactions = new ArrayList<>();
    }

    // Methods
    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            transactions.add("Deposited: " + amount);
            System.out.println("Deposit successful. \n New balance: " + balance);
        } else {
            System.out.println("Invalid deposit amount.");
        }
    }

    public void withdraw(double amount) throws InsufficientFundsException {
        if (amount > 0 && amount <= balance) {
            balance -= amount;
            transactions.add("Withdrew: " + amount);
            System.out.println("Withdrawal successful. \n New balance: " + balance);
        } else {
            throw new InsufficientFundsException("Insufficient funds or invalid amount.");
        }
    }

    public void displayAccountDetails() {
        System.out.println("Account Number: " + accountNumber);
        System.out.println("Account Holder: " + accountHolderName);
        System.out.println("Balance: " + balance);
    }

    public void displayTransactionHistory() {
        System.out.println("Transaction History: \n ");
        for (String transaction : transactions) {
            System.out.println(transaction);
        }
    }

}
