
import java.util.Scanner;
public class BankApp {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        SavingsAccount account = new SavingsAccount("1842004", "Maha Mamdouh", 5000);

        int choice;
        do {
            System.out.println("\n1. Display Account Details");
            System.out.println("2. Deposit");
            System.out.println("3. Withdraw");
            System.out.println("4. Transaction History");
            System.out.println("5. Exit");
            System.out.println("Enter your choice: ");
            choice = scanner.nextInt();

            try {
                switch (choice) {
                    case 1 -> account.displayAccountDetails();
                    case 2 -> {
                        System.out.println("Enter amount to deposit: ");
                        double amount = scanner.nextDouble();
                        account.deposit(amount);
                    }
                    case 3 -> {
                        System.out.println("Enter amount to withdraw: ");
                        double amount = scanner.nextDouble();
                        account.withdraw(amount);
                    }
                    case 4 -> account.displayTransactionHistory();
                    case 5-> System.out.println("Exiting....");
                    default -> System.out.println("Invalid choice.");
                }
            } catch (InsufficientFundsException e) {
                System.out.println("Error: " + e.getMessage());
            }
        } while (choice != 5);

        scanner.close();
    }
}
