
// SavingsAccount subclass
public class SavingsAccount extends BankAccount {
    private static final double MINIMUM_BALANCE = 500.0;

    public SavingsAccount(String accountNumber, String accountHolderName, double balance) {
        super(accountNumber, accountHolderName, balance);
    }

    @Override
    public void withdraw(double amount) throws InsufficientFundsException {
        if (balance - amount >= MINIMUM_BALANCE) {
            super.withdraw(amount);
        } else {
            throw new InsufficientFundsException("Cannot withdraw below the minimum balance of " + MINIMUM_BALANCE);
        }
    }
}

